
package com.ecommerce;

import java.sql.*;
import java.util.Scanner;

public class OrderManagement {

    static Scanner sc = new Scanner(System.in);

    // Valid order statuses
    static final String[] VALID_STATUSES = {
            "Pending", "Shipped", "Delivered", "Cancelled"
    };

    // ================= MAIN MENU =================

    public static void main(String[] args) {

        try (Connection connection = DBConnection.getConnection()) {

            System.out.println("==========================================");
            System.out.println("     E-COMMERCE ORDER MANAGEMENT SYSTEM");
            System.out.println("==========================================");
            System.out.println("Database connected successfully!");

            int choice;

            do {
                System.out.println("\n========== MAIN MENU ==========");
                System.out.println("1. Insert 3 Sample Orders");
                System.out.println("2. Search Orders by Status");
                System.out.println("3. Increase Order Quantity");
                System.out.println("4. Update Order Status");
                System.out.println("5. Display Total Order Value");
                System.out.println("6. Delete Cancelled Order");
                System.out.println("7. Exit");
                System.out.println("==============================");

                System.out.print("Enter your choice: ");
                choice = readInt();

                switch (choice) {

                    case 1:
                        insertSampleOrders(connection);
                        break;

                    case 2:
                        searchOrders(connection);
                        break;

                    case 3:
                        increaseQuantity(connection);
                        break;

                    case 4:
                        updateStatus(connection);
                        break;

                    case 5:
                        displayTotalOrderValue(connection);
                        break;

                    case 6:
                        deleteCancelledOrder(connection);
                        break;

                    case 7:
                        System.out.println("Thank you for using the system!");
                        break;

                    default:
                        System.out.println("Invalid choice! Try again.");
                }

            } while (choice != 7);

        } catch (SQLException e) {

            System.out.println("Database connection error!");
            System.out.println(e.getMessage());
        }
    }

    // ================= A: INSERT ORDERS =================

    static void insertSampleOrders(Connection con) {

        String sql = "INSERT INTO Orders " +
                "(order_id, customer_name, product_name, quantity, unit_price, status) " +
                "VALUES (?, ?, ?, ?, ?, ?)";

        Object[][] orders = {
                {101, "Rahul", "Laptop", 2, 55000.0, "Pending"},
                {102, "Aman", "Headphones", 5, 1500.0, "Shipped"},
                {103, "Priya", "Keyboard", 3, 2500.0, "Cancelled"}
        };

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            for (Object[] order : orders) {

                ps.setInt(1, (int) order[0]);
                ps.setString(2, (String) order[1]);
                ps.setString(3, (String) order[2]);
                ps.setInt(4, (int) order[3]);
                ps.setDouble(5, (double) order[4]);
                ps.setString(6, (String) order[5]);

                try {
                    ps.executeUpdate();
                    System.out.println("Order " + order[0] + " inserted successfully!");

                } catch (SQLIntegrityConstraintViolationException e) {
                    System.out.println("Order ID " + order[0] +
                            " already exists. Skipping duplicate.");
                }
            }

        } catch (SQLException e) {

            System.out.println("Error inserting orders: " + e.getMessage());
        }
    }

    // ================= B: SEARCH ORDERS =================

    static void searchOrders(Connection con) {

        System.out.print("Enter order status: ");
        String status = sc.nextLine();

        String sql = "SELECT * FROM Orders " +
                "WHERE status = ? AND quantity > 2 " +
                "ORDER BY unit_price DESC";

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, status);

            try (ResultSet rs = ps.executeQuery()) {

                System.out.println("\n--- SEARCH RESULTS ---");

                boolean found = false;

                while (rs.next()) {

                    found = true;

                    printOrder(rs);
                }

                if (!found) {
                    System.out.println("No matching orders found.");
                }
            }

        } catch (SQLException e) {

            System.out.println("Error searching orders: " + e.getMessage());
        }
    }

    // ================= C: INCREASE QUANTITY =================

    static void increaseQuantity(Connection con) {

        System.out.print("Enter Order ID: ");
        int orderId = readInt();

        System.out.print("Enter additional quantity: ");
        int additionalQuantity = readInt();

        if (additionalQuantity <= 0) {
            System.out.println("Additional quantity must be greater than 0.");
            return;
        }

        String sql = "UPDATE Orders SET quantity = quantity + ? " +
                "WHERE order_id = ?";

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, additionalQuantity);
            ps.setInt(2, orderId);

            int rows = ps.executeUpdate();

            if (rows > 0) {

                System.out.println("Quantity updated successfully!");

                displayOrderById(con, orderId);

            } else {

                System.out.println("Order does not exist.");
            }

        } catch (SQLException e) {

            System.out.println("Error updating quantity: " + e.getMessage());
        }
    }

    // ================= D: UPDATE STATUS =================

    static void updateStatus(Connection con) {

        System.out.print("Enter Order ID: ");
        int orderId = readInt();

        // Check whether order exists
        String checkSql = "SELECT * FROM Orders WHERE order_id = ?";

        try (PreparedStatement checkPs = con.prepareStatement(checkSql)) {

            checkPs.setInt(1, orderId);

            try (ResultSet rs = checkPs.executeQuery()) {

                if (!rs.next()) {

                    System.out.println("Order does not exist.");
                    return;
                }

                System.out.println("\nCurrent Order Details:");
                printOrder(rs);
            }

        } catch (SQLException e) {

            System.out.println("Error retrieving order: " + e.getMessage());
            return;
        }

        System.out.print("Enter new status (Pending/Shipped/Delivered): ");
        String newStatus = sc.nextLine();

        if (!isValidStatus(newStatus)) {

            System.out.println("Invalid status!");
            System.out.println("Valid statuses: Pending, Shipped, Delivered, Cancelled");
            return;
        }

        String sql = "UPDATE Orders SET status = ? WHERE order_id = ?";

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, newStatus);
            ps.setInt(2, orderId);

            ps.executeUpdate();

            System.out.println("\nStatus updated successfully!");
            System.out.println("Updated Order Details:");

            displayOrderById(con, orderId);

        } catch (SQLException e) {

            System.out.println("Error updating status: " + e.getMessage());
        }
    }

    // ================= E: TOTAL ORDER VALUE =================

    static void displayTotalOrderValue(Connection con) {

        String sql = "SELECT SUM(quantity * unit_price) AS total_value " +
                "FROM Orders";

        try (Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            if (rs.next()) {

                double total = rs.getDouble("total_value");

                System.out.println("\n================================");
                System.out.printf("Total Order Value: Rs. %.2f%n", total);
                System.out.println("================================");
            }

        } catch (SQLException e) {

            System.out.println("Error calculating total: " + e.getMessage());
        }
    }

    // ================= F: DELETE CANCELLED ORDER =================

    static void deleteCancelledOrder(Connection con) {

        System.out.print("Enter Order ID to delete: ");
        int orderId = readInt();

        String sql = "DELETE FROM Orders " +
                "WHERE order_id = ? AND status = 'Cancelled'";

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, orderId);

            int rows = ps.executeUpdate();

            if (rows > 0) {

                System.out.println("Cancelled order deleted successfully!");

            } else {

                System.out.println("Order cannot be deleted.");
                System.out.println("Either the order does not exist " +
                        "or its status is not Cancelled.");
            }

        } catch (SQLException e) {

            System.out.println("Error deleting order: " + e.getMessage());
        }
    }

    // ================= HELPER METHODS =================

    static void displayOrderById(Connection con, int orderId) {

        String sql = "SELECT * FROM Orders WHERE order_id = ?";

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, orderId);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {
                    printOrder(rs);
                }
            }

        } catch (SQLException e) {

            System.out.println("Error retrieving order: " + e.getMessage());
        }
    }

    static void printOrder(ResultSet rs) throws SQLException {

        System.out.println("------------------------------------------");
        System.out.println("Order ID      : " + rs.getInt("order_id"));
        System.out.println("Customer Name : " + rs.getString("customer_name"));
        System.out.println("Product Name  : " + rs.getString("product_name"));
        System.out.println("Quantity      : " + rs.getInt("quantity"));
        System.out.println("Unit Price    : Rs. " + rs.getDouble("unit_price"));
        System.out.println("Status        : " + rs.getString("status"));
        System.out.println("------------------------------------------");
    }

    static boolean isValidStatus(String status) {

        for (String validStatus : VALID_STATUSES) {

            if (validStatus.equalsIgnoreCase(status)) {
                return true;
            }
        }

        return false;
    }

    static int readInt() {

        while (true) {

            try {

                int value = Integer.parseInt(sc.nextLine());
                return value;

            } catch (NumberFormatException e) {

                System.out.print("Please enter a valid integer: ");
            }
        }
    }
}
